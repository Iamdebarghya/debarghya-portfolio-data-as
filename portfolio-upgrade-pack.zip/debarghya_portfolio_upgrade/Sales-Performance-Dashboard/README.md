# Sales Performance Dashboard
Streamlit CSV dashboard with configurable field mapping, KPI cards, monthly trend, region/category summaries, filtered data preview and CSV export.
Run: `pip install -r requirements.txt` then `streamlit run app.py`. Requires at least one numeric sales/revenue column.
