import pandas as pd
import plotly.express as px
import streamlit as st
st.set_page_config(page_title="Sales Performance",page_icon="📊",layout="wide")
st.title("Sales Performance Dashboard")
st.caption("Upload a CSV to explore revenue and segment performance.")
f=st.file_uploader("Upload sales CSV",type=["csv"])
if not f: st.info("Upload a CSV to begin."); st.stop()
try: df=pd.read_csv(f)
except Exception as e: st.error(f"CSV read error: {e}"); st.stop()
if df.empty: st.warning("No records found."); st.stop()
nums=[c for c in df if pd.api.types.is_numeric_dtype(df[c])]
if not nums: st.error("No numeric column found."); st.stop()
st.sidebar.header("Column mapping")
amount=st.sidebar.selectbox("Sales amount",nums)
opts=["(none)"]+list(df.columns)
date=st.sidebar.selectbox("Date",opts); region=st.sidebar.selectbox("Region",opts); category=st.sidebar.selectbox("Category",opts)
d=df.copy(); d[amount]=pd.to_numeric(d[amount],errors="coerce"); d=d.dropna(subset=[amount])
if region!="(none)":
    vals=sorted(d[region].dropna().astype(str).unique())
    chosen=st.sidebar.multiselect("Regions",vals,default=vals)
    d=d[d[region].astype(str).isin(chosen)]
a,b,c=st.columns(3); a.metric("Total sales",f"{d[amount].sum():,.2f}"); b.metric("Average",f"{d[amount].mean():,.2f}" if len(d) else "0"); c.metric("Records",f"{len(d):,}")
if date!="(none)":
    d[date]=pd.to_datetime(d[date],errors="coerce")
    t=d.dropna(subset=[date]).assign(Month=lambda x:x[date].dt.to_period("M").dt.to_timestamp()).groupby("Month",as_index=False)[amount].sum()
    if not t.empty: st.subheader("Monthly sales"); st.plotly_chart(px.line(t,x="Month",y=amount,markers=True),use_container_width=True)
l,r=st.columns(2)
if region!="(none)":
    x=d.groupby(region,as_index=False)[amount].sum(); l.subheader("Sales by region"); l.plotly_chart(px.bar(x,x=region,y=amount),use_container_width=True)
if category!="(none)":
    x=d.groupby(category,as_index=False)[amount].sum(); r.subheader("Sales by category"); r.plotly_chart(px.bar(x,x=category,y=amount),use_container_width=True)
st.subheader("Filtered data"); st.dataframe(d,use_container_width=True)
st.download_button("Download filtered CSV",d.to_csv(index=False).encode("utf-8-sig"),"sales_filtered.csv","text/csv")
