import argparse, csv, os, sys
import requests
from dotenv import load_dotenv

def main():
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", required=True)
    parser.add_argument("--output", default="public_leads.csv")
    args = parser.parse_args()
    key = os.getenv("SERPAPI_KEY")
    if not key:
        sys.exit("Missing SERPAPI_KEY. Add it to .env; never commit the key.")
    try:
        response = requests.get("https://serpapi.com/search.json",
            params={"engine":"google","q":args.query,"api_key":key,"num":20}, timeout=25)
        response.raise_for_status()
        results = response.json().get("organic_results", [])
    except requests.RequestException as exc:
        sys.exit(f"Search failed: {exc}")
    rows = [{"title":r.get("title",""),"snippet":r.get("snippet",""),
             "profile_url":r.get("link",""),"source":"Public Google result"}
            for r in results if "linkedin.com/in/" in r.get("link","")]
    with open(args.output,"w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=["title","snippet","profile_url","source"])
        w.writeheader(); w.writerows(rows)
    print(f"Saved {len(rows)} public results to {args.output}")
if __name__ == "__main__": main()
