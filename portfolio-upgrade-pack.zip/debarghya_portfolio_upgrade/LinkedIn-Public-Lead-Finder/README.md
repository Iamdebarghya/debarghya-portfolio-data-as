# LinkedIn Public Lead Finder
A search-provider based tool for publicly indexed professional pages. It does not log into LinkedIn, bypass controls, scrape private pages, or harvest sensitive data.
Setup: `pip install -r requirements.txt`; copy `.env.example` to `.env`; add your own SerpAPI key; run `python app.py --query 'site:linkedin.com/in/ data analyst Kolkata'`.
Exports normalized public search results to CSV. Follow provider terms and applicable privacy rules.
