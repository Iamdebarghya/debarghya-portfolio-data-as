USE sales_warehouse;
INSERT IGNORE INTO dim_date VALUES
(20230101,'2023-01-01',2023,1,1,'January'),(20230102,'2023-01-02',2023,1,1,'January'),
(20230201,'2023-02-01',2023,1,2,'February'),(20230301,'2023-03-01',2023,1,3,'March');
INSERT IGNORE INTO dim_region(region_name) VALUES('North'),('South'),('East'),('West');
INSERT IGNORE INTO dim_product(product_name,category) VALUES('Product A','A'),('Product B','B'),('Product C','A');
INSERT IGNORE INTO fact_sales(source_sale_id,date_key,region_key,product_key,quantity,unit_price,sales_amount)
SELECT 'S-1001',20230101,r.region_key,p.product_key,2,500,1000 FROM dim_region r JOIN dim_product p
WHERE r.region_name='North' AND p.product_name='Product A' AND p.category='A';
INSERT IGNORE INTO fact_sales(source_sale_id,date_key,region_key,product_key,quantity,unit_price,sales_amount)
SELECT 'S-1002',20230102,r.region_key,p.product_key,3,500,1500 FROM dim_region r JOIN dim_product p
WHERE r.region_name='South' AND p.product_name='Product B' AND p.category='B';
