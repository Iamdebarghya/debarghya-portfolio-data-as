CREATE DATABASE IF NOT EXISTS sales_warehouse;
USE sales_warehouse;
CREATE TABLE IF NOT EXISTS dim_date (
 date_key INT PRIMARY KEY, full_date DATE NOT NULL UNIQUE,
 year_num SMALLINT NOT NULL, quarter_num TINYINT NOT NULL,
 month_num TINYINT NOT NULL, month_name VARCHAR(12) NOT NULL
);
CREATE TABLE IF NOT EXISTS dim_region (
 region_key INT AUTO_INCREMENT PRIMARY KEY, region_name VARCHAR(100) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS dim_product (
 product_key INT AUTO_INCREMENT PRIMARY KEY, product_name VARCHAR(150) NOT NULL,
 category VARCHAR(100), UNIQUE KEY uq_product(product_name,category)
);
CREATE TABLE IF NOT EXISTS fact_sales (
 sales_key BIGINT AUTO_INCREMENT PRIMARY KEY, source_sale_id VARCHAR(64) NOT NULL UNIQUE,
 date_key INT NOT NULL, region_key INT NOT NULL, product_key INT NOT NULL,
 quantity INT NOT NULL CHECK(quantity>=0), unit_price DECIMAL(12,2) NOT NULL CHECK(unit_price>=0),
 sales_amount DECIMAL(14,2) NOT NULL CHECK(sales_amount>=0),
 loaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY ix_fact_date(date_key), KEY ix_fact_region(region_key), KEY ix_fact_product(product_key),
 FOREIGN KEY(date_key) REFERENCES dim_date(date_key),
 FOREIGN KEY(region_key) REFERENCES dim_region(region_key),
 FOREIGN KEY(product_key) REFERENCES dim_product(product_key)
);
