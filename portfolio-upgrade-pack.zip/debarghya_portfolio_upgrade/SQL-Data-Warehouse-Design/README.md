# SQL Data Warehouse Design
MySQL 8 dimensional sales warehouse. Execute schema.sql, sample_data.sql, then analytics.sql.
Model: dim_date, dim_region, dim_product and fact_sales at one-row-per-sale-line grain. Uses surrogate keys, foreign keys, DECIMAL currency, uniqueness and basic checks.
