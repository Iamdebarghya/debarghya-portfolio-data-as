USE sales_warehouse;
SELECT d.year_num,d.month_num,d.month_name,SUM(f.sales_amount) revenue,
       SUM(f.quantity) units_sold,AVG(f.sales_amount) avg_line_value
FROM fact_sales f JOIN dim_date d ON d.date_key=f.date_key
GROUP BY d.year_num,d.month_num,d.month_name ORDER BY d.year_num,d.month_num;
SELECT p.product_name,p.category,SUM(f.sales_amount) revenue,SUM(f.quantity) units_sold
FROM fact_sales f JOIN dim_product p ON p.product_key=f.product_key
GROUP BY p.product_key,p.product_name,p.category ORDER BY revenue DESC LIMIT 10;
SELECT r.region_name,SUM(f.sales_amount) revenue
FROM fact_sales f JOIN dim_region r ON r.region_key=f.region_key
GROUP BY r.region_key,r.region_name ORDER BY revenue DESC;
SELECT source_sale_id,COUNT(*) duplicate_count FROM fact_sales
GROUP BY source_sale_id HAVING COUNT(*)>1;
