# HR Dashboard | Advanced Excel
Upgrade the existing workbook with Power Query cleaning, Excel Tables, PivotTables/Data Model and slicers.
Suggested KPIs: headcount, active employees, hires, exits, attrition rate (period exits / average period headcount), average tenure and department-wise headcount.
Validate date boundaries, blank termination dates and denominator definitions. Use only columns actually present in the workbook. Keep individual compensation and demographic details out of public screenshots.
