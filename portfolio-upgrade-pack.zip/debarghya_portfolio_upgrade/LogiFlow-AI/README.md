# LogiFlow AI
AI-assisted logistics platform starter.
Stack: Expo SDK 54 + React Native + TypeScript, FastAPI, PostgreSQL/PostGIS, Firebase Auth/FCM/Storage, Google Maps.
Core modules: shipment management, nearest available truck matching within 20 km, delay alerts, voice-note workflow, cost-per-km calculator.
Matching must filter by availability and capacity, rank by distance, and require confirmation before booking. Keep secrets in environment variables, never in Git.
See architecture.md and postgis_matching.sql.
