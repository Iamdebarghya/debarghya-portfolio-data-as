CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TABLE IF NOT EXISTS trucks (
 id BIGSERIAL PRIMARY KEY, registration_no TEXT UNIQUE NOT NULL,
 capacity_kg NUMERIC(12,2) NOT NULL CHECK(capacity_kg > 0),
 status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available','booked','in_transit','inactive')),
 location GEOGRAPHY(POINT,4326) NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS trucks_location_gix ON trucks USING GIST(location);
-- Longitude first, latitude second. Distance radius is 20 km.
SELECT id, registration_no, capacity_kg,
 ST_Distance(location, ST_SetSRID(ST_MakePoint(:longitude,:latitude),4326)::geography)/1000 AS distance_km
FROM trucks
WHERE status='available' AND capacity_kg >= :required_capacity_kg
 AND ST_DWithin(location, ST_SetSRID(ST_MakePoint(:longitude,:latitude),4326)::geography,20000)
ORDER BY distance_km LIMIT 20;
