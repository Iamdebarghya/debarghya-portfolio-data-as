# Architecture
Entities: users, trucks, shipments, matches, delay_events, trip_costs.
API outline: GET /health; POST /trucks; GET /trucks/nearby; POST /shipments; GET /shipments/{id}/matches; POST /matches/{id}/confirm; POST /shipments/{id}/delay-events; POST /shipments/{id}/cost-estimate.
Reliability: role-based access, audit logs, coordinate validation, UTC timestamps, idempotent booking, and ETA confidence/last-updated labels.
